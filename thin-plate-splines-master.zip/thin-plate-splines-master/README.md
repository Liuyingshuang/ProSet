**This repository has been archived.**

thin-plate-splines
==================

A C++ implementation of polyharmonic/thin-plate spline transformation/interpolation.

A deformation of the unit cube using thin-plate splines:
![Deformation of the unit cube using thin-plate splines](https://raw.github.com/vladimir-ch/vladimir-ch.github.io/master/images/tps_sample.png)
